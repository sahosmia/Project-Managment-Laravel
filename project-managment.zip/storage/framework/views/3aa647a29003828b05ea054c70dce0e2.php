<?php $__env->startSection('content'); ?>
<h1>sahos</h1>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\pc\Desktop\project-managment\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>