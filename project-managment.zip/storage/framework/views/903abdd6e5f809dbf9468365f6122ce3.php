<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['paginator']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['paginator']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<?php if($paginator->hasPages()): ?>
<div class="flex justify-between items-center px-4 py-3">
    
    <div class="text-sm text-slate-500">
        Showing <b><?php echo e($paginator->firstItem()); ?> - <?php echo e($paginator->lastItem()); ?></b> of <?php echo e($paginator->total()); ?>

    </div>

    
    <div class="flex space-x-1">
        
        <?php if($paginator->onFirstPage()): ?>
        <span
            class="px-3 py-1 min-w-9 min-h-9 text-sm text-slate-400 bg-white border border-slate-200 rounded cursor-not-allowed">
            Prev
        </span>
        <?php else: ?>
        <a href="<?php echo e($paginator->previousPageUrl()); ?>"
            class="px-3 py-1 min-w-9 min-h-9 text-sm font-normal text-slate-500 bg-white border border-slate-200 rounded hover:bg-slate-50 hover:border-slate-400 transition duration-200 ease">
            Prev
        </a>
        <?php endif; ?>

        
        <?php $__currentLoopData = $paginator->getUrlRange(1, $paginator->lastPage()); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page => $url): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if($page == $paginator->currentPage()): ?>
        <span
            class="px-3 py-1 min-w-9 min-h-9 text-sm font-normal text-white bg-brand-800 border border-brand-800 rounded">
            <?php echo e($page); ?>

        </span>
        <?php else: ?>
        <a href="<?php echo e($url); ?>"
            class="px-3 py-1 min-w-9 min-h-9 text-sm font-normal text-slate-500 bg-white border border-slate-200 rounded hover:bg-slate-50 hover:border-slate-400 transition duration-200 ease">
            <?php echo e($page); ?>

        </a>
        <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        
        <?php if($paginator->hasMorePages()): ?>
        <a href="<?php echo e($paginator->nextPageUrl()); ?>"
            class="px-3 py-1 min-w-9 min-h-9 text-sm font-normal text-slate-500 bg-white border border-slate-200 rounded hover:bg-slate-50 hover:border-slate-400 transition duration-200 ease">
            Next
        </a>
        <?php else: ?>
        <span
            class="px-3 py-1 min-w-9 min-h-9 text-sm text-slate-400 bg-white border border-slate-200 rounded cursor-not-allowed">
            Next
        </span>
        <?php endif; ?>
    </div>
</div>
<?php endif; ?>
<?php /**PATH C:\Users\pc\Desktop\project-managment\resources\views/vendor/pagination/tailwind.blade.php ENDPATH**/ ?>